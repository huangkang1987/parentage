================================================

Input genotype 199 loci.txt

The genotypes of song sparrows (Melospiza melodi) at all 199 autosomal microsatellites from Nietlisbach et al. (2015, Mol Ecol Resour, doi:10.5061/dryad.689v4). 

================================================

Input genotype 40 loci.txt

The genotypes of song sparrows (Melospiza melodi) at 40 autosomal microsatellites which show evidence of null alleles from Nietlisbach et al. (2015, Mol Ecol Resour, doi:10.5061/dryad.689v4). 

================================================

Application (I) offspring.txt   

The offspring of Application (I): identifying one parent when the genotype of the other parent is known. The first column is the offspring identifier, the second column is the known parent identifier (e.g. known mother), the following columns are candidate parents (e.g. candidate fathers). The true parent is in the third column. 

================================================

Application (II) offspring.txt

The offspring of Application (II): identifying one parent when the genotype of the other parent is unknown. The first column is the offspring identifier, the second column is the known parent identifier (left blank), the following columns are candidate parents (e.g. candidate fathers). The true parent is in the third column. 

================================================

Application (III) offspring.txt   

The offspring file of Application (III): identifying father and mother jointly when the sexes of candidate parents are known. There is only one column and each row show one offspring identifier. 

================================================

Application (III) candidate fathers.txt   

The candidate fathers file of Application (III): identifying father and mother jointly when the sexes of candidate parents are known. There is only one column and each row show one candidate father. 

================================================

Application (III) candidate mothers.txt   

The candidate mothers file of Application (III): identifying father and mother jointly when the sexes of candidate parents are known. There is only one column and each row show one candidate mother. 

================================================

Application (IV) offspring.txt   

The offspring file of Application (IV): identifying father and mother jointly when the sexes of candidate parents are unknown. The contents are identical to 'Application (III) offspring.txt'. 

================================================

Application (IV) candidate parents.txt

The candidate parents file of Application (IV): identifying father and mother jointly when the sexes of candidate parents are unknown. Which is a combination of 'Application (III) candidate fathers.txt' and 'Application (III) candidate mothers.txt'. 

================================================

Application (III) (IV) results.txt

The results of Applications (III) and (IV), the first, second and third columns are the identifiers of the offspring, true father and true mother, respectively. 

================================================
